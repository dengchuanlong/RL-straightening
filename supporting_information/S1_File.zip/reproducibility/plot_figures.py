"""Recreate six scientific figures from the frozen numerical study.

Python/matplotlib only. No observational rows are discarded. The quantitative
examples use the condition and seed specified before evaluation in config.json.
Figures 1–2 are conceptual diagrams, not finite-element or physical images.
"""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path
import subprocess
import sys
from collections import defaultdict

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon
from matplotlib.lines import Line2D
from matplotlib.transforms import ScaledTranslation

BASE = Path(__file__).resolve().parent
OUT = BASE.parent / "figures"
QA = OUT / "qa"
OUT.mkdir(exist_ok=True)
QA.mkdir(exist_ok=True)
CFG = json.loads((BASE / "config.json").read_text())
SKILL = Path(os.environ.get("NATURE_FIGURE_SCRIPTS", str(OUT / "qa_tools")))
sys.path.insert(0, str(SKILL))
from audit_panel_alignment import require_matplotlib_panel_alignment

plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
    "font.size": 8.5, "axes.labelsize": 8.5, "xtick.labelsize": 8,
    "ytick.labelsize": 8, "legend.fontsize": 8, "legend.frameon": False, "axes.titlesize": 9,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": .65, "xtick.major.width": .65, "ytick.major.width": .65,
    "xtick.major.size": 3, "ytick.major.size": 3, "lines.linewidth": 1.5,
    "pdf.fonttype": 42, "svg.fonttype": "none", "savefig.facecolor": "white",
})
BLUE = "#2166AC"
LIGHT_BLUE = "#78A8C9"
GRAY = "#575B60"
LIGHT_GRAY = "#9CA3AA"
ORANGE = "#D17B24"
PALE = "#EAF2F8"
METHODS = ["rl", "rl_no_shaping", "bisection", "false_position", "random_bracket", "uniform_grid", "closed_form"]
NAMES = {"rl": "RL (shaped)", "rl_no_shaping": "RL (unshaped)", "bisection": "Bisection / untrained", "false_position": "False position", "random_bracket": "Random bracket", "uniform_grid": "Uniform grid", "closed_form": "Closed-form oracle"}
COLORS = {"rl": BLUE, "rl_no_shaping": LIGHT_BLUE, "bisection": GRAY, "false_position": "#25282B", "random_bracket": "#878D94", "uniform_grid": "#ADB2B7", "closed_form": ORANGE}
STYLES = {"rl": "-", "rl_no_shaping": "--", "bisection": "--", "false_position": "-.", "random_bracket": ":", "uniform_grid": (0, (1, 2)), "closed_form": "-"}
STOCHASTIC = {"rl", "rl_no_shaping", "random_bracket"}
CAPTIONS = {}
PANELS = []


def rows(filename):
    with (BASE / "results" / filename).open(newline="") as f:
        return list(csv.DictReader(f))


def arr(rs, key):
    return np.asarray([float(r[key]) for r in rs])


def panel(ax, letter, title=None):
    ax.set_gid(letter)
    trans = ax.transAxes + ScaledTranslation(-24 / 72, 8 / 72, ax.figure.dpi_scale_trans)
    ax.text(0, 1, letter, transform=trans, weight="bold", fontsize=10, va="bottom", ha="left")
    if title:
        ax.set_title(title, loc="left", pad=11)


def basefig(height_mm):
    return plt.figure(figsize=(190 / 25.4, height_mm / 25.4))


def arrow(ax, xy1, xy2, color=GRAY, lw=1.2, style="-|>"):
    ax.add_patch(FancyArrowPatch(xy1, xy2, arrowstyle=style, mutation_scale=9,
                                linewidth=lw, color=color, shrinkA=3, shrinkB=3))


def box(ax, xy, wh, lines, fill=PALE, edge=BLUE, fontsize=8.5):
    x, y = xy
    w, h = wh
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.012,rounding_size=0.012",
                               facecolor=fill, edgecolor=edge, linewidth=.8))
    if isinstance(lines, str):
        lines = lines.split("\n")
    step = fontsize * 1.35 / (ax.get_position().height * ax.figure.get_figheight() * 72)
    for i, text in enumerate(lines):
        ax.text(x + w / 2, y + h / 2 + (len(lines) - 1) * step / 2 - i * step,
                text, ha="center", va="center", fontsize=fontsize)


def finalize(fig, name, groups=None):
    fig.canvas.draw()
    extra = groups or {}
    align = require_matplotlib_panel_alignment(fig, json_out=QA / f"{name}.alignment.json",
        overlay_svg=QA / f"{name}.alignment.svg", tolerance_pt=1.5,
        gutter_tolerance_pt=1.5, require_panel_labels=True, strict=True, **extra)
    for ext in ("pdf", "svg"):
        fig.savefig(OUT / f"{name}.{ext}")
    fig.savefig(OUT / f"{name}.png", dpi=300)
    fig.savefig(OUT / f"{name}.tif", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    assert (OUT / f"{name}.tif").stat().st_size < 10_000_000
    plt.close(fig)
    print(name, align["verdict"], flush=True)


def fig1():
    fig = basefig(116)
    gs = fig.add_gridspec(1, 4, left=.06, right=.98, top=.83, bottom=.37, wspace=.20)
    stages = [("Pre-bend", -.25, "q = u", "Virgin state → plastic state"),
              ("First unloading", -.16, "q = q0; F = 0", "Store the same state p0"),
              ("Reverse trial", .12, "q = q0 − s", "Apply one candidate stroke s"),
              ("Final unloading", -.025, "q = r(s); F = 0", "Measure unloaded residual")]
    for j, (title, sag, lab, note) in enumerate(stages):
        ax = fig.add_subplot(gs[0, j]); ax.set_xlim(0, 1); ax.set_ylim(-.52, .60); ax.axis("off")
        panel(ax, "abcd"[j], title)
        x = np.linspace(.08, .92, 100); y = sag * (1 - ((x - .5) / .42) ** 2)
        ax.plot([.04, .96], [0, 0], color=LIGHT_GRAY, lw=.8, ls="--")
        ax.plot(x, y, color=BLUE, lw=2.2)
        for xx in [.08, .92]:
            support_sign = -1 if j == 2 else 1
            tri = Polygon([[xx - .045, -.09 * support_sign], [xx + .045, -.09 * support_sign], [xx, -.015 * support_sign]], closed=True,
                          facecolor="#DADEE2", edgecolor=GRAY, linewidth=.8)
            ax.add_patch(tri)
        if j in [0, 2]:
            start = (.5, .45) if j == 0 else (.5, -.32)
            end = (.5, sag + .03) if j == 0 else (.5, sag - .03)
            arrow(ax, start, end, ORANGE, 1.6)
        ax.text(.5, .53, lab, ha="center", va="top", fontsize=8.5)
        lines = note.split(" → ") if " → " in note else [note]
        if j == 0: lines = ["Virgin state to", "plastic state"]
        elif j == 1: lines = ["Store the same", "plastic state p0"]
        elif j == 2: lines = ["One candidate", "stroke s"]
        else: lines = ["Read the unloaded", "midpoint residual"]
        for k, text in enumerate(lines):
            ax.text(.5, -.39 - k*.10, text, ha="center", va="top", fontsize=8)
    fig.text(.5, .96, "Reduced-order straightening sequence", ha="center", fontsize=11, weight="bold")
    fig.text(.075, .25, "q is one generalized midpoint displacement; positive q follows the pre-bend direction.", fontsize=8.5)
    fig.text(.075, .19, "The spring stores plastic displacement p:  F = k(q − p),  backstress = H p.", fontsize=8.5)
    fig.text(.075, .13, "Every candidate starts again from p0; trial queries do not accumulate physical strokes.", fontsize=8.5)
    fig.text(.075, .07, "Schematic shapes are illustrative. The model does not predict a full deflection profile.", color=GRAY, fontsize=8)
    CAPTIONS["Fig1"] = "Reduced-order process and displacement definitions. Panels a–d depict pre-bending, force-free unloading, one reverse candidate loading, and final force-free unloading. The diagrams illustrate sign and sequence, not finite-element fields or measured beam shapes. The reverse-loading fixture is drawn inverted to preserve the original displacement coordinate. Each candidate is restored to the same stored post-prebend plastic state p0. q is one midpoint generalized coordinate, and r(s) is its final unloaded value; the 0.1 mm criterion is not a full-profile straightness tolerance. Figure preparation was assisted by OpenAI Codex."
    finalize(fig, "Fig1")


def fig2():
    fig = basefig(174)
    gs = fig.add_gridspec(2, 1, left=.07, right=.97, top=.92, bottom=.06, hspace=.25, height_ratios=[.8, 1.3])
    ax = fig.add_subplot(gs[0]); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    panel(ax, "a", "Independent conditions and frozen evaluation")
    box(ax, (.015,.49), (.24,.30), ["Training: 4,000", "60,000 episodes × 5 seeds"], fontsize=8)
    box(ax, (.38,.49), (.23,.30), ["Freeze Q tables", "No test-driven selection"], fill="#F1F2F3", edge=GRAY, fontsize=8)
    box(ax, (.735,.49), (.25,.30), ["Validation: 400", "IID test: 600", "Thickness shift: 600"], fontsize=8)
    arrow(ax, (.26,.64), (.37,.64)); arrow(ax, (.62,.64), (.725,.64))
    ax.text(.015,.26,"Independent random draws; h = 7–9 mm for training, validation and IID test.",fontsize=8.5)
    ax.text(.015,.12,"Thickness shift changes h to 9.25–10 mm within the same assigned equations.",fontsize=8.5)
    ax = fig.add_subplot(gs[1]); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    panel(ax, "b", "Outcome-driven virtual candidate search")
    box(ax,(.015,.71),(.27,.21),["Query s = 0 and 24 mm", "Initialize signed bracket"],fill="#F1F2F3",edge=GRAY,fontsize=8)
    box(ax,(.365,.71),(.27,.21),["Aggregate observation z", "Select action from Q(z, a)"],fontsize=8)
    box(ax,(.715,.71),(.27,.21),["s = lo + f(hi − lo)", "Restore p0 and query r(s)"],fontsize=8)
    arrow(ax,(.29,.815),(.36,.815));arrow(ax,(.64,.815),(.71,.815))
    box(ax,(.715,.33),(.27,.21),["Update bracket and best s", "Stop at |r| ≤ 0.1 mm", "or after 12 total queries"],fontsize=8)
    box(ax,(.365,.33),(.27,.21),["Return updated observation", "Update Q during training"],fontsize=8)
    arrow(ax,(.85,.70),(.85,.55));arrow(ax,(.71,.435),(.64,.435));arrow(ax,(.5,.55),(.5,.70))
    ax.text(.02,.60,"Both endpoint calls",fontsize=8,color=GRAY)
    ax.text(.02,.54,"count toward the budget.",fontsize=8,color=GRAY)
    ax.text(.015,.20,"z = bins[residual balance, bracket width, best |r| / 0.1, remaining-call class]",fontsize=8.5)
    ax.text(.015,.105,"f in {0.10, 0.25, 0.50, 0.75, 0.90};  Q size = 20 × 10 × 9 × 3 × 5 = 27,000",fontsize=8.5)
    ax.text(.015,.015,"Evaluation uses a frozen greedy policy; no analytical root enters observations or rewards.",fontsize=8)
    CAPTIONS["Fig2"] = "Simulation and reinforcement-learning workflow. (a) Fresh independent condition sets are used for training, descriptive validation, IID testing and a thickness-shift test; all learned seeds are frozen before evaluation and retained. (b) A candidate action selects a fraction of the current signed bracket. Every query restores the stored post-prebend state. Aggregated observations discretize residual balance rho = r_lo/(r_lo−r_hi), bracket width, best residual relative to tolerance, and the remaining-call class. Both initialization endpoints count in the 12-call budget. Q updates and potential-based reward shaping occur during training only. Figure preparation was assisted by OpenAI Codex."
    finalize(fig,"Fig2")


def fig3():
    fd=rows("representative_force_displacement.csv");rc=rows("representative_response_curve.csv")
    fig=basefig(100);gs=fig.add_gridspec(1,2,left=.105,right=.97,bottom=.34,top=.83,wspace=.35)
    ax=fig.add_subplot(gs[0]);panel(ax,"a","Loading and unloading response")
    stage_style={"prebend":("Pre-bend",GRAY,"-"),"first_unload":("First unload",LIGHT_GRAY,"--"),"corrective_load":("Reverse loading",BLUE,"-"),"final_unload":("Final unload",ORANGE,"--")}
    for stage,(lab,c,ls) in stage_style.items():
        rr=[r for r in fd if r["stage"]==stage];ax.plot(arr(rr,"q_mm"),arr(rr,"F_N")/1000,color=c,ls=ls,label=lab)
    ax.axhline(0,color="#B5B9BD",lw=.6);ax.set_xlabel("Generalized displacement q (mm)");ax.set_ylabel("Force F (kN)")
    ax.set_xticks([-8,-4,0,4,8,12,16]);ax.set_yticks([-8,-4,0,4,8]);ax.set_xlim(-8,17);ax.set_ylim(-9,9)
    assert arr(fd,"q_mm").min() > -8 and arr(fd,"q_mm").max() < 17
    ax.legend(loc="upper center",bbox_to_anchor=(.5,-.28),ncol=2,columnspacing=.9,handlelength=2)
    ax=fig.add_subplot(gs[1]);panel(ax,"b","Candidate stroke and final residual")
    ax.plot(arr(rc,"stroke_mm"),arr(rc,"residual_mm"),color=BLUE)
    ax.axhspan(-.1,.1,color=ORANGE,alpha=.25);ax.axhline(0,color=GRAY,lw=.6)
    pc=[r for r in rows("per_case_results.csv") if r["case_id"]=="test_0000" and r["method"]=="closed_form"][0]
    root=float(pc["selected_stroke_mm"]);ax.plot(root,0,"o",ms=4,color=ORANGE)
    ax.set_xlabel("Candidate stroke s (mm)");ax.set_ylabel("Final signed residual r(s) (mm)")
    ax.set_xlim(0,24);ax.set_xticks([0,6,12,18,24]);ax.set_yticks([-10,-5,0,5,10]);ax.set_ylim(-11,11)
    ax.legend(handles=[Line2D([],[],color=BLUE,label="Forward model"),Line2D([],[],marker="o",ls="",color=ORANGE,label="Analytical root")],loc="upper center",bbox_to_anchor=(.5,-.28),ncol=2,columnspacing=.9,handlelength=2)
    fig.text(.5,.965,"Prespecified condition: test_0000",ha="center",fontsize=10)
    fig.text(.5,.04,"A numerical constitutive audit; agreement with an analytical expression is not physical validation.",ha="center",fontsize=8)
    CAPTIONS["Fig3"] = "Executed constitutive response for the prespecified test condition test_0000. (a) Force–displacement traces from virgin loading, first unloading, corrective loading at the analytical zero-residual stroke, and final unloading. (b) Final unloaded residual versus independently evaluated candidate stroke; the orange point denotes the analytical root, and the band denotes ±0.1 mm. Lines contain all exported samples. The globally reported return-map/analytical agreement verifies the assigned numerical equations, not experimental or finite-element accuracy. Source data: representative_force_displacement.csv and representative_response_curve.csv. Figure preparation was assisted by OpenAI Codex; values were produced by the documented numerical simulation."
    finalize(fig,"Fig3")


def fig4():
    tr=rows("training_trace.csv");fig=basefig(92);gs=fig.add_gridspec(1,3,left=.085,right=.975,bottom=.38,top=.83,wspace=.42)
    metrics=[("train_mean_calls","Mean forward queries",[5,6,7,8,9,10],(5,10)),("train_success_rate","Training success (%)",[70,80,90,100],(70,101)),("train_mean_reward","Episode reward",[-4,0,4,8],(-4,9))]
    for j,(key,ylab,ticks,ylim) in enumerate(metrics):
        ax=fig.add_subplot(gs[j]);panel(ax,"abc"[j])
        for meth in ["rl","rl_no_shaping"]:
            rr=[r for r in tr if r["variant"]==meth];eps=sorted(set(int(r["episode"]) for r in rr))
            vals=np.array([[float(r[key]) for r in rr if int(r["episode"])==e] for e in eps])
            assert vals.shape==(60,5)
            if key=="train_success_rate":vals*=100
            mu=vals.mean(axis=1);sd=vals.std(axis=1,ddof=1);xx=np.array(eps)/1000
            ax.fill_between(xx,mu-sd,mu+sd,color=COLORS[meth],alpha=.20,lw=0)
            ax.plot(xx,mu,color=COLORS[meth],ls=STYLES[meth],label=NAMES[meth])
        ax.set_xlabel("Episode (thousands)");ax.set_ylabel(ylab);ax.set_xlim(0,60);ax.set_xticks([0,20,40,60]);ax.set_yticks(ticks);ax.set_ylim(*ylim)
    fig.legend(handles=[Line2D([],[],color=COLORS[m],ls=STYLES[m],label=NAMES[m]) for m in ["rl","rl_no_shaping"]],loc="lower center",bbox_to_anchor=(.5,.155),ncol=2)
    fig.text(.5,.955,"Exploratory training: mean ± SD across five seeds",ha="center",fontsize=10)
    fig.text(.5,.085,"Each point summarizes 1,000 episodes; ε decreases from 0.8 to 0.02 during training.",ha="center",fontsize=8)
    fig.text(.5,.035,"Training rewards differ by shaping term; these curves are not frozen-policy test results.",ha="center",fontsize=8)
    CAPTIONS["Fig4"] = "Exploratory training trajectories. (a) Mean forward queries per episode, including both bracket endpoints. (b) Training success at the 0.1 mm residual threshold. (c) Reward under each variant's own reward definition; shaped and unshaped reward levels are not identical objectives. Each line averages five independently trained policies, and the band is ±1 sample SD across seeds. Points are consecutive 1,000-episode block summaries, with no additional smoothing. Epsilon follows the documented schedule, so training performance is distinct from frozen-policy evaluation. Source data: training_trace.csv. Figure preparation was assisted by OpenAI Codex; values were produced by the documented numerical simulation."
    finalize(fig,"Fig4")


def fig5():
    sm=rows("summary_by_seed.csv");sb=rows("success_by_budget.csv")
    # Combine two exactly equivalent policies only after checking their outputs.
    per=rows("per_case_results.csv")
    b={(r["split"],r["case_id"]):(r["forward_calls"],r["selected_stroke_mm"],r["final_signed_residual_mm"]) for r in per if r["method"]=="bisection"}
    u={(r["split"],r["case_id"]):(r["forward_calls"],r["selected_stroke_mm"],r["final_signed_residual_mm"]) for r in per if r["method"]=="untrained"}
    assert b==u
    fig=basefig(176);gs=fig.add_gridspec(2,2,left=.24,right=.97,bottom=.20,top=.92,wspace=.35,hspace=.48)
    for j,split in enumerate(["test","thickness_shift"]):
        ax=fig.add_subplot(gs[0,j]);panel(ax,"ab"[j],"IID test" if split=="test" else "Thickness shift")
        for k,m in enumerate(METHODS):
            vv=np.array([float(r["mean_forward_calls"]) for r in sm if r["split"]==split and r["method"]==m])
            mu=vv.mean();sd=vv.std(ddof=1) if len(vv)>1 else 0
            ax.errorbar(mu,k,xerr=sd,fmt="o" if m in STOCHASTIC else "s",ms=4,color=COLORS[m],capsize=2,lw=1.2)
        ax.set_yticks(range(len(METHODS)));ax.set_yticklabels([NAMES[m] for m in METHODS] if j==0 else [])
        ax.set_ylim(6.6,-.6);ax.set_xlim(0,12);ax.set_xticks([0,3,6,9,12]);ax.set_xlabel("Mean forward queries")
        ax.grid(axis="x",color="#E7E9EB",lw=.6)
        ax=fig.add_subplot(gs[1,j]);panel(ax,"cd"[j])
        for m in METHODS:
            rr=[r for r in sb if r["split"]==split and r["method"]==m];xx=np.arange(1,13)
            vv=np.array([[float(r["success_rate"]) for r in rr if int(r["call_budget"])==c] for c in xx])*100
            mu=vv.mean(axis=1);sd=vv.std(axis=1,ddof=1) if vv.shape[1]>1 else np.zeros(12)
            ax.fill_between(xx,mu-sd,mu+sd,color=COLORS[m],alpha=.14,lw=0,step="post")
            ax.step(xx,mu,where="post",color=COLORS[m],ls=STYLES[m],lw=1.6 if m=="rl" else 1.15)
        ax.set_xlim(1,12);ax.set_ylim(0,104);ax.set_xticks([1,3,6,9,12]);ax.set_yticks([0,25,50,75,100]);ax.set_xlabel("Total forward-query budget")
        if j==0:ax.set_ylabel("Cases meeting tolerance (%)")
    fig.legend(handles=[Line2D([],[],color=COLORS[m],ls=STYLES[m],label=NAMES[m]) for m in METHODS],loc="lower center",bbox_to_anchor=(.5,.065),ncol=3,handlelength=2.5,columnspacing=1.6)
    fig.text(.5,.025,"600 cases per split; endpoints included; stochastic summaries show mean ± one seed SD.",ha="center",fontsize=8)
    CAPTIONS["Fig5"] = "Forward-query cost and success under frozen evaluation. (a,b) Mean query counts over 600 shared conditions for the IID and thickness-shift sets. Stochastic methods show the mean and ±1 sample SD of five seed-level means; deterministic methods show one value. Failed cases remain in the cost denominator. (c,d) Cumulative proportion meeting |r|≤0.1 mm by each total query budget, with the same seed uncertainty convention. The two initialization endpoints are counted for all bracket/grid searches. The closed-form reference uses one forward verification call. Bisection and the untrained zero-Q policy are combined only after exact output equality was checked. The uniform-grid and strong false-position/analytical references are retained. Training cost is separate and is not included in these inference-only panels. Source data: summary_by_seed.csv, success_by_budget.csv, per_case_results.csv. Figure preparation was assisted by OpenAI Codex; values were produced by the documented numerical simulation."
    finalize(fig,"Fig5")


def fig6():
    rr=[r for r in rows("representative_rollout.csv") if r["method"]=="rl" and r["seed"]=="1101"]
    assert all(r["case_id"]=="test_0000" for r in rr)
    x=arr(rr,"evaluation");s=arr(rr,"stroke_mm");r=arr(rr,"residual_mm")
    pc=[z for z in rows("per_case_results.csv") if z["case_id"]=="test_0000" and z["method"]=="closed_form"][0]
    exact=float(pc["selected_stroke_mm"])
    fig=basefig(100);gs=fig.add_gridspec(1,2,left=.10,right=.97,bottom=.27,top=.83,wspace=.36)
    ax=fig.add_subplot(gs[0]);panel(ax,"a","Candidate strokes")
    ax.plot(x,s,"o-",color=BLUE,ms=4);ax.scatter(x[:2],s[:2],color=GRAY,s=20,zorder=5)
    ax.axhline(exact,color=ORANGE,ls="--",lw=1.1);ax.set_ylabel("Trial stroke s (mm)");ax.set_xlabel("Forward evaluation number")
    ax.set_ylim(-1,25);ax.set_yticks([0,6,12,18,24]);ax.set_xticks(x.astype(int));ax.set_xlim(.7,x[-1]+.3)
    ax=fig.add_subplot(gs[1]);panel(ax,"b","Returned unloaded residual")
    ax.axhspan(-.1,.1,color=ORANGE,alpha=.16)
    ax.plot(x,r,"o-",color=BLUE,ms=4);ax.scatter(x[:2],r[:2],color=GRAY,s=20,zorder=5)
    ax.axhline(.1,color=ORANGE,ls="--",lw=.8);ax.axhline(-.1,color=ORANGE,ls="--",lw=.8)
    ax.set_yscale("symlog",linthresh=.1,linscale=1);ax.set_ylim(-15,15);ax.set_yticks([-10,-1,-.1,0,.1,1,10]);ax.set_yticklabels(["−10","−1","−0.1","0","0.1","1","10"])
    ax.set_ylabel("Signed residual r (mm; symlog)");ax.set_xlabel("Forward evaluation number");ax.set_xticks(x.astype(int));ax.set_xlim(.7,x[-1]+.3)
    fig.text(.5,.96,"Prespecified rollout: test_0000, RL seed 1101",ha="center",fontsize=10)
    handles=[Line2D([],[],marker="o",color=BLUE,label="Virtual candidate"),Line2D([],[],marker="o",color=GRAY,ls="",label="Bracket endpoints"),Line2D([],[],color=ORANGE,ls="--",label="Analytical root / ±0.1 mm")]
    fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(.5,.115),ncol=3,columnspacing=1.5,handlelength=2)
    fig.text(.5,.065,"Each point is a fresh trial from the same p0; connecting lines show query order.",ha="center",fontsize=8)
    fig.text(.5,.025,f"Final evaluated stroke = {s[-1]:.5f} mm; residual = {r[-1]:.5f} mm; total queries = {len(rr)}.",ha="center",fontsize=8)
    CAPTIONS["Fig6"] = "Prespecified policy rollout. The condition test_0000 and learned seed 1101 were fixed in the configuration before evaluation. (a) Candidate stroke against the cumulative forward-call count; the dashed line is the analytical root used only as a post-freeze diagnostic. (b) Signed unloaded residual with a symmetric-log axis, linear inside ±0.1 mm; the shaded region is the acceptance interval. Gray points are the mandatory endpoints. Each point restarts from the same stored post-prebend state, so connecting lines indicate virtual query order, not accumulated physical corrections. All seven evaluations are shown, including initialization; the final query satisfies the prescribed tolerance. Source data: representative_rollout.csv. Figure preparation was assisted by OpenAI Codex; values were produced by the documented numerical simulation."
    finalize(fig,"Fig6")


def audit_all():
    commands=[("source",[str(SKILL/"validate_figure.py"),str(Path(__file__)),"--json"])]
    for name in CAPTIONS:
        commands.extend([(f"{name}.text",[str(SKILL/"audit_pdf_text.py"),str(OUT/f"{name}.pdf"),"--min-pt","8","--json"]),
            (f"{name}.collisions",[str(SKILL/"audit_figure_collisions.py"),str(OUT/f"{name}.pdf"),"--json-out",str(QA/f"{name}.collision-audit.json"),"--overlay-pdf",str(QA/f"{name}.collision-audit.pdf")])])
    failures=[]
    for name,args in commands:
        result=subprocess.run([sys.executable,*args],capture_output=True,text=True,encoding="utf-8",errors="replace")
        (QA/f"{name}.log").write_text(result.stdout+result.stderr,encoding="utf-8")
        if result.returncode:failures.append((name,result.returncode))
    (QA/"execution_qa.json").write_text(json.dumps({"failures":failures},indent=2))
    print("QA failures:",failures,flush=True)


if __name__=="__main__":
    names=sys.argv[1:]
    funcs={f"Fig{i}":globals()[f"fig{i}"] for i in range(1,7)}
    for name,fn in funcs.items():
        if not names or name in names:fn()
    existing={}
    cp=OUT/"captions.json"
    if cp.exists():existing=json.loads(cp.read_text(encoding="utf-8"))
    existing.update(CAPTIONS);cp.write_text(json.dumps(existing,indent=2,ensure_ascii=False),encoding="utf-8")
    audit_all()

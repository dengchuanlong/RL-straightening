"""Summarize the saved frozen-run CSVs, without retraining or policy selection.

Paired bootstrap uncertainty resamples CONDITIONS, after averaging the five RL
policies per condition. It is conditional on these five frozen policies. It is
not a confidence interval over all possible RL retrainings.
"""
from pathlib import Path
from collections import defaultdict
import csv
import hashlib
import json
import math
import numpy as np

BASE=Path(__file__).resolve().parent
OUT=BASE/"results"


def read_csv(path):
    with path.open(encoding="utf-8",newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path,rows):
    with path.open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def wilson(k,n,z=1.959963984540054):
    p=k/n;den=1+z*z/n
    center=(p+z*z/(2*n))/den
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [max(0.0,center-half),min(1.0,center+half)]


def bootstrap_pair(diff,rng,reps=10000):
    samples=[]
    for _ in range(reps//1000):
        idx=rng.integers(0,len(diff),(1000,len(diff)))
        samples.append(diff[idx].mean(axis=1))
    allsamples=np.concatenate(samples,axis=0)
    return {"difference_mean":np.mean(diff,axis=0).tolist(),"percentile95_ci":np.quantile(allsamples,[0.025,0.975],axis=0).tolist(),"n_conditions":len(diff),"bootstrap_replicates":reps,"bootstrap_unit":"condition, after averaging five RL policies per condition"}


def main():
    rows=read_csv(OUT/"per_case_results.csv")
    byseed=read_csv(OUT/"summary_by_seed.csv")
    cost=read_csv(OUT/"training_cost.csv")
    config=json.loads((BASE/"config.json").read_text(encoding="utf-8"))
    metrics=["success_rate","mean_forward_calls","mean_abs_residual_mm","rmse_residual_mm","mean_stroke_abs_error_mm"]
    grouped=defaultdict(list)
    for r in byseed:grouped[(r["split"],r["method"])].append(r)
    aggregate=[]
    for (split,method),rr in grouped.items():
        d={"split":split,"method":method,"n_conditions_per_seed":int(rr[0]["n_cases"]),"n_policy_or_random_seeds":len(rr)}
        for metric in metrics:
            vals=np.array([float(x[metric]) for x in rr])
            d[metric+"_mean"]=float(vals.mean())
            d[metric+"_seed_sd"]=float(vals.std(ddof=1)) if len(vals)>1 else 0.0
        aggregate.append(d)
    write_csv(OUT/"summary_aggregate.csv",aggregate)
    rng=np.random.default_rng(4411)
    bootstrap={}; shaping={}; success={}; breakeven={}
    bycase=defaultdict(list)
    for r in rows:bycase[(r["split"],r["method"],r["case_id"])].append(r)
    rlcost=np.array([float(r["training_forward_calls"]) for r in cost if r["variant"]=="rl"])
    for split in ("test","thickness_shift"):
        cases=sorted(k[2] for k in bycase if k[0]==split and k[1]=="bisection")
        diffs=[]
        for case in cases:
            rl=bycase[(split,"rl",case)]
            bis=bycase[(split,"bisection",case)][0]
            diffs.append([np.mean([float(r["forward_calls"]) for r in rl])-float(bis["forward_calls"]),np.mean([float(r["final_abs_residual_mm"]) for r in rl])-float(bis["final_abs_residual_mm"])])
        boot=bootstrap_pair(np.array(diffs),rng)
        boot["metric_order"]=["RL_minus_bisection_forward_calls","RL_minus_bisection_abs_residual_mm"]
        bootstrap[split]=boot
        ra={int(r["seed"]):r for r in grouped[(split,"rl")]}
        ns={int(r["seed"]):r for r in grouped[(split,"rl_no_shaping")]}
        shap={}
        for metric in ("mean_forward_calls","mean_abs_residual_mm","success_rate"):
            diff=np.array([float(ra[s][metric])-float(ns[s][metric]) for s in config["rl_seeds"]])
            mean=float(diff.mean()); sd=float(diff.std(ddof=1)); half=2.7764451051977987*sd/math.sqrt(5)
            shap[metric]={"RL_minus_no_shaping_seed_differences":diff.tolist(),"mean":mean,"sample_sd":sd,"descriptive_t95_interval_df4":[mean-half,mean+half],"interpretation":"descriptive across five seed pairs; no significance claim; equal episode budgets"}
        shaping[split]=shap
        n_conditions=int(ra[config["rl_seeds"][0]]["n_cases"])
        nsuccess={str(s):int(round(float(ra[s]["success_rate"])*n_conditions)) for s in config["rl_seeds"]}
        unique_success=set(nsuccess.values())
        success[split]={"successes_per_policy":next(iter(unique_success)) if len(unique_success)==1 else nsuccess,"successes_by_seed":nsuccess,"independent_conditions_per_policy":n_conditions,"wilson95_per_policy":wilson(next(iter(unique_success)),n_conditions) if len(unique_success)==1 else {s:wilson(k,n_conditions) for s,k in nsuccess.items()},"policy_seeds":len(ra),"warning":"Repeated evaluations of the same conditions across policy seeds are not independent test conditions."}
        biscalls=float(grouped[(split,"bisection")][0]["mean_forward_calls"])
        rlcalls=np.array([float(ra[s]["mean_forward_calls"]) for s in config["rl_seeds"]])
        savings=biscalls-rlcalls
        breakeven[split]={"mean_RL_training_forward_calls_per_policy":float(rlcost.mean()),"mean_RL_inference_forward_calls":float(rlcalls.mean()),"bisection_inference_forward_calls":biscalls,"mean_saved_queries_per_condition":float(savings.mean()),"inference_relative_query_reduction_percent":float(100*savings.mean()/biscalls),"mean_training_calls_divided_by_mean_savings":float(rlcost.mean()/savings.mean()),"per_seed_break_even_cases":(rlcost/savings).tolist(),"assumptions":"Equal cost per forward query; one trained policy is deployed repeatedly to conditions from this split; excludes model-training arithmetic, all other overhead, and validation; no break-even against false position or closed-form because those use fewer inference calls."}
    policy_rows=[]
    for seed in config["rl_seeds"]:
        data=np.load(BASE/"models"/f"rl_{seed}.npz")
        Q=data["Q"];visits=data["visits"]
        for st in np.ndindex(Q.shape[:-1]):
            if visits[st].sum()==0:continue
            maximum=float(np.max(Q[st]));a=next(j for j in (2,1,3,0,4) if float(Q[st][j])>=maximum-1e-12)
            policy_rows.append({"seed":seed,"ratio_bin":st[0],"width_bin":st[1],"best_error_bin":st[2],"remaining_calls_bin":st[3],"greedy_action_fraction":config["action_fractions"][a],"state_visits":int(visits[st].sum()),**{f"Q_{str(fr).replace('.','p')}":float(Q[st+(j,)]) for j,fr in enumerate(config["action_fractions"])}})
    write_csv(OUT/"learned_policy_visited_states.csv",policy_rows)
    totals={"training_forward_calls_primary_five_policies":int(rlcost.sum()),"training_forward_calls_no_shaping_five_policies":sum(int(r["training_forward_calls"]) for r in cost if r["variant"]=="rl_no_shaping"),"training_forward_calls_all_ten_policies":sum(int(r["training_forward_calls"]) for r in cost),"evaluation_forward_calls_all_methods_all_splits":sum(int(r["forward_calls"]) for r in rows),"all_training_plus_evaluation_forward_calls":sum(int(r["training_forward_calls"]) for r in cost)+sum(int(r["forward_calls"]) for r in rows),"mechanics_audits_and_figure_only_calls_excluded":True,"forward_query_definition":"one corrective load and force-free unload from the stored post-prebend state","initial_prebend_state_preparations_separate_from_candidate_queries":sum(config["split_n"].values())}
    result={"aggregate_seed_summaries":aggregate,"paired_bootstrap_seed":4411,"paired_bootstrap":bootstrap,"shaping_ablation":shaping,"success_wilson":success,"amortization":breakeven,"total_cost":totals,"scope":"Postprocessing of saved frozen-run results. No retraining, method selection, or settings change."}
    (OUT/"derived_summary.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    (BASE/"requirements.txt").write_text("numpy=="+np.__version__+"\n",encoding="utf-8")
    hashes={str(p.relative_to(BASE)).replace("\\","/"):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(BASE.rglob("*")) if p.is_file() and p.name!="sha256_manifest.json" and "__pycache__" not in p.parts}
    (BASE/"sha256_manifest.json").write_text(json.dumps(hashes,indent=2),encoding="utf-8")
    print(json.dumps({"paired_bootstrap":bootstrap,"amortization":breakeven,"total_cost":totals,"numpy_version":np.__version__},indent=2))


if __name__=="__main__":main()

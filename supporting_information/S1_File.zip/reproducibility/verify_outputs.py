"""Audit saved output consistency and replay frozen policies without training."""
import csv
import json
from pathlib import Path
import numpy as np
import run_study as study

BASE=Path(__file__).resolve().parent


def read(path):
    with path.open(encoding="utf-8",newline="") as f:return list(csv.DictReader(f))


def main():
    rows=read(BASE/"results"/"per_case_results.csv")
    keys=[(r["split"],r["method"],r["seed"],r["case_id"]) for r in rows]
    assert len(set(keys))==len(keys)==32000
    assert all(int(r["success"])==int(float(r["final_abs_residual_mm"])<=study.TOL) for r in rows)
    assert all(1<=int(r["forward_calls"])<=study.BUDGET for r in rows)
    assert all(0<=float(r["selected_stroke_mm"])<=study.MAXS for r in rows)
    cases=[]
    for split in study.CFG["split_n"]:
        data=read(BASE/"data"/(split+"_conditions.csv"))
        assert len(data)==study.CFG["split_n"][split]
        cases.extend(tuple(r[f] for f in study.FIELDS) for r in data)
    assert len(set(cases))==len(cases)==5600
    representative=read(BASE/"data"/"test_conditions.csv")[0]
    count=0
    # Counter instrumentation ensures reported candidate queries equal actual
    # calls, including endpoints. The original stored row is compared directly.
    for method,seed in [("rl",1101),("rl_no_shaping",1101),("bisection",0),("false_position",0),("uniform_grid",0),("closed_form",0),("untrained",0),("random_bracket",1101)]:
        env=study.BeamSpring(representative)
        Q=None
        if method in ("rl","rl_no_shaping"):
            Q=np.load(BASE/"models"/f"{method}_{seed}.npz")["Q"]
        elif method=="untrained":Q=np.zeros(study.SHAPE)
        original=env.trial
        seen=[0]
        def counted(s):
            seen[0]+=1
            return original(s)
        env.trial=counted
        actual,_=study.evaluate_one(env,method,seed,Q)
        expected=next(r for r in rows if r["split"]=="test" and r["case_id"]=="test_0000" and r["method"]==method and int(r["seed"])==seed)
        assert actual["forward_calls"]==seen[0]==int(expected["forward_calls"])
        for key in ("selected_stroke_mm","final_signed_residual_mm","selected_corrective_peak_force_N"):
            assert abs(actual[key]-float(expected[key]))<1e-12
        count+=1
    result={"unique_result_records":len(rows),"unique_condition_tuples":len(cases),"result_success_flags_consistent":True,"all_strokes_and_call_counts_inside_prespecified_bounds":True,"frozen_replays_matched":count,"instrumented_candidate_query_counts_matched":True,"policy_retraining_performed":False}
    (BASE/"results"/"output_consistency_checks.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))


if __name__=="__main__":main()

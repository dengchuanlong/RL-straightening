# Source context and separation from the new experiment

The two author-supplied contextual manuscripts were *Mechanics guided residual ensembles for straightening stroke prediction* (1025, 31 PDF pages) and *Mechanics guided spline residual ensemble for straightening stroke prediction* (1026, 22 PDF pages). They are treated as contextual drafts, not asserted published articles. Authors named in both: Yang Yan, Chuanlong Deng and Wenbo Huang.

The new simulation reuses their declared rectangular-design parameter envelope (b,h,L,Rp,Rs,u) and numerical reference constants E=204401 MPa and sigma=1000.121 MPa. The hardening ratio beta=0.02, one-degree-of-freedom mechanical environment, state/action/reward design, new condition sets, policies and all reported RL outcomes are new computational work in this package. The constants are assigned; they are not a newly identified material card. The numerical scripts use the same support span for prebending and correction, rather than reconstructing the proposed separate prebending fixture of the drafts.

The contextual drafts describe supervised regression on a different 9000-row table. That table is publicly accessible at https://github.com/dengchuanlong/straightening/tree/8d720ae63039fe47a3b1481b2127535b01d60f9e/data . Its values and labels were not used for this RL experiment. No old regression score was transferred as an RL result.

The release's DATA_PROVENANCE.md and scripts/verify_source_lineage.py document numerical agreement of its 81000 numerical entries with a prior analytical development dataset. The source declaration also reports an author assertion of finite-element origin, while noting that no new native solver files were supplied. This unresolved source declaration does not establish row-level FE provenance. The present new simulations are therefore explicitly reduced-order analytical mechanics and do not claim to reproduce that original table or the separate historical circular-beam pilot.

Original immutable releases:

- 1025: https://github.com/dengchuanlong/straightening/tree/b8f03925a8b4d22954d4c1ac1eee2d86ec58ce0f
- 1026: https://github.com/dengchuanlong/straightening/tree/8d720ae63039fe47a3b1481b2127535b01d60f9e
- Provenance: https://github.com/dengchuanlong/straightening/blob/8d720ae63039fe47a3b1481b2127535b01d60f9e/DATA_PROVENANCE.md

The accompanying author guide records source-page comparisons and the distinction between virtual reset-based search and repeated physical pressing. Human authors should verify their source/publication status and intellectual contribution before submitting a new article.

## Later engineering release and local source inspection

Following the author's direction to inspect GitHub code and data, the current repository was also examined at commit `0960d0fcbf32a5824725853d7d381f7feeeeb22d`. Unlike the two manuscript-linked versions above, this release includes `engineering/Supplementary_Software_1.zip`, native input snapshots, material and model sources, parsed reference cases, solver receipts and search histories. Its 182 payload hashes were checked, and its cold-input preparation entry point was executed without launching a solver. The earlier absence-of-native-files finding is restricted to the old manuscript-linked releases and does not describe this later engineering package.

The full original project and Mechanical APDL 2026 R1 were subsequently located on the author's local machine using paths recorded in that source. Local records include 19 distinct six-input geometries; three dense B-mesh searches contain 47 historical candidate evaluations. These existing records are separate from the newly executed reduced-order results in this directory. Their objective is maximum full-centroid-line deviation after complete unloading, with a strict 1 mm feasibility threshold plus material/contact/release screens; it is not the signed midpoint residual or 0.1 mm tolerance used here. They must not be counted as newly executed RL validations.

The current release's `data/` and `scripts/` trees are unchanged from the 1026 version. A new local execution of the inspected lineage checker confirmed agreement of all 81,000 numerical entries and all 9,000 partition assignments; the canonical data hash remained unchanged. The added engineering cases do not establish a row-level native-solver mapping for the historical 9,000-row table.

See the accompanying `author_notes/github_current_audit.md` for exact paths, source hashes, checks and isolation requirements for any new native computations. The public engineering methods are available at https://github.com/dengchuanlong/straightening/blob/0960d0fcbf32a5824725853d7d381f7feeeeb22d/engineering/FE_REFERENCE_METHODS.md .

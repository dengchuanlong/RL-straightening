# New virtual straightening reinforcement-learning study

This directory contains an executed, deterministic-seeded numerical feasibility study using a one-degree-of-freedom bilinear kinematic-hardening spring. It is **new simulation data**, not a reproduction of the 9,000-record table mentioned in source manuscript 1026. The historical table and regression code are publicly accessible through the papers' GitHub releases; see `source_context.md` for their provenance and separation from this experiment. This package contains no physical measurements or verified FE-derived labels.

## Reproduce

Python 3.11 or later and NumPy are sufficient. No Torch, SciPy, GPU, or external solver is used.

```powershell
python -m pip install -r requirements.txt
python run_study.py
python verify_outputs.py
python derive_summary.py
```

The recorded primary execution used the bundled Python runtime on Windows and took approximately 110 seconds. Exact wall time depends on hardware. Running the scripts regenerates their output files in this directory; scientific comparisons are based on forward-query counts rather than wall time.

`run_study.py` writes and hashes the prespecified configuration before generating data or training. It trains all five primary policies and all five no-shaping policies before any validation/test/shift evaluation. The validation partition is descriptive; no settings or seeds are selected. The `derive_summary.py` script replays only saved CSV results and generates aggregate tables, paired conditional-on-policy bootstrap intervals, an amortization calculation, a readable learned-policy table, and file hashes. It performs no training or tuning.

## Files

- `config.json`: frozen numerical assumptions, design ranges, sample sizes, seeds, observation bins, actions, rewards, and evaluation rules.
- `data/*_conditions.csv`: 4,000 training, 400 validation, 600 IID-test, and 600 thickness-shift conditions. Six input columns `b,h,L,Rp,Rs,u` are in mm. Rp and Rs are inactive in this surrogate; b affects force but cancels from the displacement response.
- `models/*.npz`: 10 trained NumPy archives with `Q`, `visits`, and `action_fractions`. Q has shape (20,10,9,3,5). Load using `numpy.load`.
- `results/training_trace.csv`: successive 1,000-episode exploratory-training block summaries, including epsilon and cumulative calls.
- `results/training_cost.csv`: training query counts for each seed and variant.
- `results/per_case_results.csv`: every evaluated method/seed/condition, including failures, selected stroke, final residual, query count, diagnostic root, and force.
- `results/summary_by_seed.csv`, `summary_aggregate.csv`: method comparisons, retaining five-seed variability without treating repeated condition evaluations as independent conditions.
- `results/success_by_budget.csv`: success fractions as a function of total forward-query budget (endpoints count).
- `results/derived_summary.json`: machine-readable aggregate statistics, case-paired bootstrap, descriptive five-seed shaping comparison, Wilson success interval, and complete query-cost accounting.
- `results/representative_*.csv`: example `test_0000` and primary seed 1101, specified before the run, for process and rollout figures. The force-displacement process uses the analytical root for its correction stage and is separately labeled from the learned rollout.
- `results/learned_policy_visited_states.csv`: readable primary-policy greedy actions and all five Q values for every visited state.
- `results/mechanics_checks.json`: executed numerical consistency checks.
- `verify_outputs.py`, `results/output_consistency_checks.json`: saved-row integrity checks and eight frozen-policy/baseline replays with instrumented actual query counts.
- `results/frozen_policy_hashes.json`, `run_manifest.json`: policy freeze evidence and execution metadata.
- `sha256_manifest.json`: hashes of package files at the time of summary generation.

## Interpretation and cost

All candidate strokes are **virtual trials reset to the identical post-prebend state**. They are not consecutive press operations on a specimen. The learner uses aggregated bracket/residual information, not supervised optimal-stroke labels. The tolerance is one unloaded midpoint deflection ≤0.1 mm; it does not establish full-profile straightness. Every bracket-search method counts two endpoint evaluations in its 12-query allowance. The closed-form inverse uses one forward verification.

A counted forward query consists of one corrective loading and final force-free unloading from the stored post-prebend state. The 5,600 one-time initial pre-bend/unload preparations are recorded separately; they are not included in corrective-candidate query counts. Mechanics audits, consistency replays, and figure-only response sweeps are also separate. These query counts must not be described as complete wall-time costs.

The simple surrogate admits a closed-form inverse, which is reported alongside bisection, false position, random bracket search, a uniform grid, and the untrained-policy control. It therefore demonstrates policy learning and conditional search efficiency, not a need for RL or superiority over all deterministic algorithms. Offline training costs are explicitly retained. No machine-force safety constraint, contact-radius response, physical validation, or high-fidelity FE equivalence is claimed.

The uncertainty bootstrap samples 600 independent **conditions**, after averaging the five frozen primary-policy outcomes on each condition. Its intervals are conditional on those policies. Five successful policies on the same 600 conditions do not provide 3,000 independent test conditions. Reward-shaping comparisons across five seeds are descriptive and do not support a significance claim.

E=204401 MPa and sigma_y=1000.121 MPa are assigned simulator constants, reused numerically from normalization references in manuscript 1026; they are not calibrated material properties. Post-yield stiffness ratio beta=0.02 is a declared assumption. The source code and manuscript methods specify the exact displacement-controlled and force-controlled return maps.

## Recreate figures

Keep the sibling `figures/qa_tools` directory when extracting S1 File. Run `python -m pip install -r requirements_figures.txt`, then `python plot_figures.py`. This generates all figure formats and repeats layout/font/collision checks. The optional figure dependencies are separate from the NumPy-only numerical study. See `source_context.md` for the contextual manuscripts, public historical-data availability and separation from the new simulation.

"""Reproducible virtual straightening study. Python 3 + numpy only.

These are NEW analytical-surrogate simulations, not finite-element analyses,
physical measurements, or reconstructions of the unsupplied 9000-row data.
Run: python run_study.py
The configuration is written and hashed before generation/training/evaluation.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import time
import numpy as np

BASE = Path(__file__).resolve().parent
CFG = {
    "study_id": "new_reduced_order_RL_straightening_2026-10-30_v1",
    "model": "one_degree_of_freedom_linear_kinematic_hardening_spring",
    "source_status": "new simulation; no original workbook, FE output, or physical measurements supplied",
    "E_MPa": 204401.0, "sigma_y_MPa": 1000.121, "post_yield_stiffness_ratio_beta": 0.02,
    "material_status": "assigned simulator constants; not calibrated material parameters",
    "ranges_mm": {"b": [30,40], "h": [7,9], "L": [180,260], "Rp": [10,25], "Rs": [10,25], "u": [12,16]},
    "shift_h_mm": [9.25,10],
    "split_n": {"train": 4000, "validation": 400, "test": 600, "thickness_shift": 600},
    "split_seed": {"train": 84111, "validation": 84112, "test": 84113, "thickness_shift": 84114},
    "rl_seeds": [1101,1102,1103,1104,1105],
    "episodes_per_seed": 60000, "trace_block_episodes": 1000,
    "stroke_bounds_mm": [0.0,24.0], "residual_tolerance_mm": 0.1, "max_forward_evaluations": 12,
    "action_fractions": [0.1,0.25,0.5,0.75,0.9],
    "ratio_edges": [i/20 for i in range(21)],
    "width_edges_mm": [0,0.125,0.25,0.5,1,2,4,8,12,18,24.000001],
    "best_residual_over_tolerance_edges": [0,1,2,4,8,16,32,64,128,256],
    "remaining_call_groups": ["1-2", "3-5", "6-10"],
    "gamma": 0.95, "initial_alpha": 0.15, "alpha_visit_scale": 50.0,
    "epsilon_start": 0.8, "epsilon_end": 0.02, "epsilon_decay_episodes": 50000,
    "success_bonus": 10.0, "budget_failure_penalty": 10.0, "cost_per_query": 1.0,
    "potential_multiplier": 0.2, "potential_log2_cap": 6.0,
    "validation_role": "prespecified descriptive check; no hyperparameter or seed selection",
    "reference_role": "analytical oracle used for mechanics audits and post-freeze diagnostics; excluded from state/reward/training",
    "force_status": "peak force is logged; no unsupported machine force capacity or force-constrained guarantee",
    "representative_rollout_rule": "test condition index 0 and RL seed 1101, specified before evaluation",
    "development_status": "single prespecified run; all final cases freshly generated; no development tuning",
}
FIELDS = ["b", "h", "L", "Rp", "Rs", "u"]
ACT = np.asarray(CFG["action_fractions"], float)
TOL = CFG["residual_tolerance_mm"]
BUDGET = CFG["max_forward_evaluations"]
MAXS = CFG["stroke_bounds_mm"][1]
GAMMA = CFG["gamma"]
SHAPE = (20,10,9,3,len(ACT))


def dump_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


def write_csv(path, rows, fields=None):
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields or list(rows[0]))
        w.writeheader()
        w.writerows(rows)


class BeamSpring:
    """Displacement and force return maps; N, mm, MPa (=N/mm2)."""
    def __init__(self, row):
        self.row = row
        self.b,self.h,self.L,self.Rp,self.Rs,self.u = [float(row[k]) for k in FIELDS]
        self.E = CFG["E_MPa"]
        self.sy = CFG["sigma_y_MPa"]
        self.beta = CFG["post_yield_stiffness_ratio_beta"]
        self.I = self.b*self.h**3/12
        self.k = 48*self.E*self.I/self.L**3
        self.Fy = 2*self.b*self.h**2*self.sy/(3*self.L)
        self.H = self.beta*self.k/(1-self.beta)
        self.dy = self.Fy/self.k
        self.p_peak,self.F_pre = self.displacement_step(self.u,0.0)
        self.p0,self.q0 = self.force_step(0.0,self.p_peak)
        self.prebend_unload_plastic = abs(self.p0-self.p_peak)>1e-10

    def displacement_step(self,q,p_old):
        f_trial = self.k*(q-p_old)
        xi = f_trial-self.H*p_old
        dg = max(0.0,(abs(xi)-self.Fy)/(self.k+self.H))
        p = p_old+math.copysign(dg,xi)
        return p,self.k*(q-p)

    def force_step(self,F,p_old):
        # A force-controlled increment is the appropriate map for force-free
        # unloading. This also handles reverse plasticity if |H*p_old| > Fy.
        xi = F-self.H*p_old
        dg = max(0.0,(abs(xi)-self.Fy)/self.H)
        p = p_old+math.copysign(dg,xi)
        return p,F/self.k+p

    def trial(self,s):
        if s < -1e-10 or s > MAXS+1e-10:
            raise ValueError("Stroke outside prescribed bounds")
        # Every virtual candidate starts from the SAME post-prebend state.
        p_load,F_load = self.displacement_step(self.q0-s,self.p0)
        p_final,q_final = self.force_step(0.0,p_load)
        return q_final,abs(F_load),abs(p_final-p_load)>1e-10

    def oracle(self):
        # Used for mechanics audits and post-freeze references, never RL reward.
        return self.p0+self.dy


def generate_conditions():
    out = {}
    for split,n in CFG["split_n"].items():
        rng = np.random.default_rng(CFG["split_seed"][split])
        rows = []
        for j in range(n):
            row = {"case_id": f"{split}_{j:04d}", "split": split}
            for name in FIELDS:
                lo,hi = CFG["shift_h_mm"] if name=="h" and split=="thickness_shift" else CFG["ranges_mm"][name]
                row[name] = float(rng.uniform(lo,hi))
            rows.append(row)
        write_csv(BASE/"data"/(split+"_conditions.csv"),rows)
        out[split] = [BeamSpring(row) for row in rows]
    return out


def bin_index(value,edges,n):
    return min(n-1,max(0,int(np.searchsorted(edges,value,side="right"))-1))


def state_index(lo,hi,rlo,rhi,best,calls):
    # Aggregated observation, not asserted to be a sufficient Markov state.
    rho = rlo/(rlo-rhi)
    remain = BUDGET-calls
    return (
        bin_index(rho,CFG["ratio_edges"],20),
        bin_index(hi-lo,CFG["width_edges_mm"],10),
        bin_index(best/TOL,CFG["best_residual_over_tolerance_edges"],9),
        0 if remain<=2 else (1 if remain<=5 else 2),
    )


def greedy_action(qrow):
    # Stable neutral tie rule: 0.5, 0.25, 0.75, 0.1, 0.9.
    best = float(np.max(qrow))
    for j in (2,1,3,0,4):
        if float(qrow[j]) >= best-1e-12:
            return j
    raise AssertionError


def potential(best,terminal=False):
    if terminal:
        return 0.0
    return -CFG["potential_multiplier"]*min(CFG["potential_log2_cap"],math.log2(max(1.0,best/TOL)))


def initial_bracket(env):
    rlo,flo,_ = env.trial(0.0)
    rhi,fhi,_ = env.trial(MAXS)
    if not rlo>0>rhi:
        raise AssertionError("Model does not provide the required bracket")
    if abs(rlo)<=abs(rhi):
        best_s,best_r,best_f = 0.0,rlo,flo
    else:
        best_s,best_r,best_f = MAXS,rhi,fhi
    return 0.0,MAXS,rlo,rhi,2,best_s,best_r,best_f,flo,fhi


def train(envs,seed,shaping=True):
    rng = np.random.default_rng(seed)
    Q = np.zeros(SHAPE,float)
    visits = np.zeros(SHAPE,np.int64)
    traces = []
    batch_calls,batch_success,batch_res,batch_reward = [],[],[],[]
    total_calls = 0
    for ep in range(CFG["episodes_per_seed"]):
        env = envs[int(rng.integers(len(envs)))]
        lo,hi,rlo,rhi,calls,bs,br,bf,_,_ = initial_bracket(env)
        eps = max(CFG["epsilon_end"],CFG["epsilon_start"]-(CFG["epsilon_start"]-CFG["epsilon_end"])*ep/CFG["epsilon_decay_episodes"])
        episode_reward = 0.0
        while calls<BUDGET and abs(br)>TOL:
            st = state_index(lo,hi,rlo,rhi,abs(br),calls)
            ai = int(rng.integers(len(ACT))) if rng.random()<eps else greedy_action(Q[st])
            s = lo+ACT[ai]*(hi-lo)
            r,f,_ = env.trial(float(s))
            old_best = abs(br)
            calls += 1
            if abs(r)<abs(br): bs,br,bf = float(s),r,f
            if r>0: lo,rlo = float(s),r
            else: hi,rhi = float(s),r
            success = abs(br)<=TOL
            terminal = success or calls==BUDGET
            reward = -CFG["cost_per_query"] + CFG["success_bonus"]*success-CFG["budget_failure_penalty"]*(terminal and not success)
            if shaping:
                reward += GAMMA*potential(abs(br),terminal)-potential(old_best)
            target = reward
            if not terminal:
                nxt = state_index(lo,hi,rlo,rhi,abs(br),calls)
                target += GAMMA*float(np.max(Q[nxt]))
            idx = st+(ai,)
            visits[idx] += 1
            alpha = CFG["initial_alpha"]/math.sqrt(1+(visits[idx]-1)/CFG["alpha_visit_scale"])
            Q[idx] += alpha*(target-Q[idx])
            episode_reward += reward
        total_calls += calls
        batch_calls.append(calls)
        batch_success.append(abs(br)<=TOL)
        batch_res.append(abs(br))
        batch_reward.append(episode_reward)
        if (ep+1)%CFG["trace_block_episodes"]==0:
            traces.append({"seed":seed,"variant":"rl" if shaping else "rl_no_shaping","episode":ep+1,"epsilon":eps,"train_success_rate":float(np.mean(batch_success)),"train_mean_calls":float(np.mean(batch_calls)),"train_mean_abs_residual_mm":float(np.mean(batch_res)),"train_mean_reward":float(np.mean(batch_reward)),"cumulative_forward_calls":total_calls,"visited_state_action_pairs":int(np.count_nonzero(visits))})
            batch_calls,batch_success,batch_res,batch_reward = [],[],[],[]
    return Q,visits,traces,total_calls


def evaluate_one(env,method,seed=0,Q=None,save_trace=False):
    trace = []
    if method=="closed_form":
        s=env.oracle()
        r,f,_=env.trial(s)
        return make_result(env,method,seed,1,s,r,f),trace
    lo,hi,rlo,rhi,calls,bs,br,bf,flo,fhi = initial_bracket(env)
    trace.append({"evaluation":1,"stroke_mm":lo,"residual_mm":rlo,"force_N":flo,"action_fraction":"endpoint","lo_before_mm":lo,"hi_before_mm":hi})
    trace.append({"evaluation":2,"stroke_mm":hi,"residual_mm":rhi,"force_N":fhi,"action_fraction":"endpoint","lo_before_mm":lo,"hi_before_mm":hi})
    rng = np.random.default_rng(seed+int(env.row["case_id"].split("_")[-1])*109)
    while calls<BUDGET and abs(br)>TOL:
        if method in ("rl","rl_no_shaping","untrained"):
            st=state_index(lo,hi,rlo,rhi,abs(br),calls)
            ai=greedy_action(Q[st])
            frac=float(ACT[ai])
            s=lo+frac*(hi-lo)
        elif method=="bisection":
            frac=0.5; s=(lo+hi)/2
        elif method=="false_position":
            frac=rlo/(rlo-rhi); s=lo+frac*(hi-lo)
        elif method=="random_bracket":
            frac=float(rng.uniform(0,1)); s=lo+frac*(hi-lo)
        elif method=="uniform_grid":
            frac=(calls-1)/(BUDGET-1); s=MAXS*frac
        else: raise ValueError(method)
        oldlo,oldhi=lo,hi
        r,f,_=env.trial(float(s)); calls+=1
        if abs(r)<abs(br): bs,br,bf=float(s),r,f
        if method!="uniform_grid":
            if r>0: lo,rlo=float(s),r
            else: hi,rhi=float(s),r
        trace.append({"evaluation":calls,"stroke_mm":s,"residual_mm":r,"force_N":f,"action_fraction":frac,"lo_before_mm":oldlo,"hi_before_mm":oldhi})
    return make_result(env,method,seed,calls,bs,br,bf),trace if save_trace else []


def make_result(env,method,seed,calls,s,r,f):
    return {"case_id":env.row["case_id"],"split":env.row["split"],"method":method,"seed":seed,"success":int(abs(r)<=TOL),"forward_calls":calls,"selected_stroke_mm":s,"final_signed_residual_mm":r,"final_abs_residual_mm":abs(r),"objective_J_mm":abs(r),"diagnostic_reference_stroke_mm":env.oracle(),"diagnostic_absolute_stroke_error_mm":abs(s-env.oracle()),"selected_corrective_peak_force_N":f,"prebend_peak_force_N":env.F_pre,"initial_residual_mm":env.p0}


def audit(envsets):
    errors=[]; maxroot=0.0; monotonic_bad=0; unload_plastic=0
    mindy,maxdy=1e99,0
    unitrow=envsets["test"][0]
    for envs in envsets.values():
        for env in envs:
            mindy=min(mindy,env.dy); maxdy=max(maxdy,env.dy)
            errors.append(abs(env.p0-(1-env.beta)*(env.u-env.dy)))
            maxroot=max(maxroot,abs(env.trial(env.oracle())[0]))
            unload_plastic += int(env.prebend_unload_plastic)
            vals=[]
            for s in np.linspace(0,MAXS,25):
                r,_,pl=env.trial(float(s)); vals.append(r); unload_plastic+=int(pl)
                sy=env.dy-env.H*env.p0/env.k
                expected=env.p0 if s<=sy else (1-env.beta)*(env.p0-s+env.dy)
                errors.append(abs(r-expected))
            monotonic_bad += int(np.max(np.diff(vals))>1e-10)
    # Elastic patch test on a virgin specimen and plastic consistency test.
    p,F=unitrow.displacement_step(0.5*unitrow.dy,0)
    pu,qu=unitrow.force_step(0,p)
    onep,oneF=unitrow.displacement_step(unitrow.u,0)
    pp=0
    for q in np.linspace(0,unitrow.u,101)[1:]: pp,ff=unitrow.displacement_step(float(q),pp)
    results={"all_conditions":sum(map(len,envsets.values())),"max_piecewise_formula_difference_mm":max(errors),"max_absolute_oracle_residual_mm":maxroot,"nonmonotone_cases":monotonic_bad,"plastic_unloading_events_on_audit_grid":unload_plastic,"yield_displacement_range_mm":[mindy,maxdy],"elastic_patch_plastic_displacement_mm":p,"elastic_patch_unloaded_residual_mm":qu,"elastic_patch_force_relative_error":abs(F-0.5*unitrow.Fy)/unitrow.Fy,"one_step_vs_100_step_prebend_difference_mm":abs(pp-onep),"units":{"E_and_sigma":"N/mm^2","I":"mm^4","k_and_H":"N/mm","Fy_and_F":"N","displacements":"mm"},"assertions_passed":max(errors)<1e-9 and maxroot<1e-9 and monotonic_bad==0 and abs(qu)<1e-12 and abs(pp-onep)<1e-9}
    assert results["assertions_passed"]
    dump_json(BASE/"results"/"mechanics_checks.json",results)
    return results


def summarize(rows):
    groups={}
    for r in rows: groups.setdefault((r["split"],r["method"],r["seed"]),[]).append(r)
    summaries=[]
    for (sp,me,se),rr in groups.items():
        summaries.append({"split":sp,"method":me,"seed":se,"n_cases":len(rr),"success_rate":float(np.mean([r["success"] for r in rr])),"mean_forward_calls":float(np.mean([r["forward_calls"] for r in rr])),"median_forward_calls":float(np.median([r["forward_calls"] for r in rr])),"mean_abs_residual_mm":float(np.mean([r["final_abs_residual_mm"] for r in rr])),"rmse_residual_mm":float(np.sqrt(np.mean([r["final_signed_residual_mm"]**2 for r in rr]))),"mean_stroke_abs_error_mm":float(np.mean([r["diagnostic_absolute_stroke_error_mm"] for r in rr])),"total_forward_calls":sum(r["forward_calls"] for r in rr)})
    return summaries


def curve_rows(rows):
    # Cumulative success by query budget; methods terminate at first success.
    groups={}
    for r in rows: groups.setdefault((r["split"],r["method"],r["seed"]),[]).append(r)
    out=[]
    for (sp,me,se),rr in groups.items():
        for budget in range(1,BUDGET+1):
            out.append({"split":sp,"method":me,"seed":se,"call_budget":budget,"success_rate":float(np.mean([r["success"] and r["forward_calls"]<=budget for r in rr]))})
    return out


def main():
    start=time.perf_counter()
    for d in ("results","data","models"): (BASE/d).mkdir(exist_ok=True)
    # This happens before any data or outcome is generated.
    dump_json(BASE/"config.json",CFG)
    confhash=hashlib.sha256((BASE/"config.json").read_bytes()).hexdigest()
    print("CONFIG_FROZEN",confhash,flush=True)
    envs=generate_conditions()
    checks=audit(envs)
    print("MECHANICS_CHECKS_PASS",checks["assertions_passed"],flush=True)
    traces=[]; train_cost=[]; policies={}
    for variant,shaping in (("rl",True),("rl_no_shaping",False)):
        for seed in CFG["rl_seeds"]:
            t=time.perf_counter()
            Q,visits,tr,calls=train(envs["train"],seed,shaping)
            np.savez_compressed(BASE/"models"/f"{variant}_{seed}.npz",Q=Q,visits=visits,action_fractions=ACT)
            traces.extend(tr)
            policies[(variant,seed)]=Q
            train_cost.append({"variant":variant,"seed":seed,"episodes":CFG["episodes_per_seed"],"training_forward_calls":calls,"training_elapsed_seconds":time.perf_counter()-t,"visited_state_action_pairs":int(np.count_nonzero(visits))})
            print("TRAINED",variant,seed,"calls",calls,"seconds",round(time.perf_counter()-t,2),flush=True)
    # Every policy is now frozen. No tuning or seed selection follows.
    write_csv(BASE/"results"/"training_trace.csv",traces)
    write_csv(BASE/"results"/"training_cost.csv",train_cost)
    frozen={f"{v}_{s}":hashlib.sha256((BASE/"models"/f"{v}_{s}.npz").read_bytes()).hexdigest() for v,s in policies}
    dump_json(BASE/"results"/"frozen_policy_hashes.json",frozen)
    rows=[]; representative=[]
    for split in ("validation","test","thickness_shift"):
        for env in envs[split]:
            for (variant,seed),Q in policies.items():
                save=split=="test" and env.row["case_id"]=="test_0000" and seed==1101
                r,tr=evaluate_one(env,variant,seed,Q,save)
                rows.append(r)
                for step in tr: representative.append({"case_id":env.row["case_id"],"method":variant,"seed":seed,**step})
            for method in ("bisection","false_position","uniform_grid","closed_form","untrained"):
                Q=np.zeros(SHAPE) if method=="untrained" else None
                save=split=="test" and env.row["case_id"]=="test_0000"
                r,tr=evaluate_one(env,method,0,Q,save)
                rows.append(r)
                for step in tr: representative.append({"case_id":env.row["case_id"],"method":method,"seed":0,**step})
            for seed in CFG["rl_seeds"]:
                r,tr=evaluate_one(env,"random_bracket",seed,None,False)
                rows.append(r)
        print("EVALUATED",split,"n",len(envs[split]),flush=True)
    write_csv(BASE/"results"/"per_case_results.csv",rows)
    summary=summarize(rows)
    write_csv(BASE/"results"/"summary_by_seed.csv",summary)
    write_csv(BASE/"results"/"success_by_budget.csv",curve_rows(rows))
    write_csv(BASE/"results"/"representative_rollout.csv",representative)
    # Full physical history for the preselected case, independent of search.
    env=envs["test"][0]
    hist=[]; p=0.0
    for q in np.linspace(0,env.u,61):
        p,F=env.displacement_step(float(q),p)
        hist.append({"stage":"prebend","q_mm":q,"F_N":F,"p_mm":p})
    for F in np.linspace(env.F_pre,0,31)[1:]:
        p,q=env.force_step(float(F),p)
        hist.append({"stage":"first_unload","q_mm":q,"F_N":F,"p_mm":p})
    for s in np.linspace(0,env.oracle(),61)[1:]:
        q=env.q0-s; p,F=env.displacement_step(float(q),p)
        hist.append({"stage":"corrective_load","q_mm":q,"F_N":F,"p_mm":p})
    Fpeak=F
    for F in np.linspace(Fpeak,0,31)[1:]:
        p,q=env.force_step(float(F),p)
        hist.append({"stage":"final_unload","q_mm":q,"F_N":F,"p_mm":p})
    write_csv(BASE/"results"/"representative_force_displacement.csv",hist)
    sweep=[]
    for s in np.linspace(0,MAXS,241):
        r,f,_=env.trial(float(s)); sweep.append({"case_id":env.row["case_id"],"stroke_mm":s,"residual_mm":r,"peak_corrective_force_N":f})
    write_csv(BASE/"results"/"representative_response_curve.csv",sweep)
    dump_json(BASE/"results"/"run_manifest.json",{"config_sha256":confhash,"numpy_version":np.__version__,"elapsed_seconds":time.perf_counter()-start,"total_training_forward_calls":sum(x["training_forward_calls"] for x in train_cost),"total_evaluation_forward_calls":sum(r["forward_calls"] for r in rows),"training_episodes_all_variants_and_seeds":10*CFG["episodes_per_seed"],"final_result_rows":len(rows),"query_accounting":"Two initial endpoint queries count in every bracket/search episode. Direct closed-form uses one verification call. Mechanics audits and diagnostic-only root calculations are excluded from algorithm cost. No initial-bracket queries are free.","selection":"No seed selection; all five trained seeds reported; no settings changed after the prespecified config freeze."})
    print("COMPLETE",round(time.perf_counter()-start,2),"seconds",flush=True)
    for r in summary:
        if r["split"]=="test": print(json.dumps(r),flush=True)


if __name__=="__main__": main()
